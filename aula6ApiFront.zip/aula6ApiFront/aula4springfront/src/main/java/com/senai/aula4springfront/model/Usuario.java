package com.senai.aula4springfront.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
public class Usuario {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    @NotBlank(message = "Nome e obrigatorio.")
    private String nome;

    @Column(nullable = false)
    @NotBlank(message = "Telefone tem que ser obrigatorio.")
    private String telefone;

    @Column(nullable = false)
    @NotBlank(message = "CPF é obrigatorio.")
    private String cpf;

    @Column(nullable = false)
    @NotBlank(message = "CEP é obrigatorio.")
    private String cep;

    @Column(nullable = false)
    @NotBlank(message = "E-mail e obrigatorio.")
    @Email(message = "Deve ser um e-mail valido.")
    private String email;

    @Column(nullable = false)
    @NotBlank(message = "Senha e obrigatorio.")
    @Size(min = 3, message = "A senha deve ter no minimo 3 caracteres.")
    private String senha;

    public Usuario() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public @NotBlank(message = "Nome e obrigatorio.") String getNome() {
        return nome;
    }

    public void setNome(@NotBlank(message = "Nome e obrigatorio.") String nome) {
        this.nome = nome;
    }

    public @NotBlank(message = "Telefone tem que ser obrigatorio.") String getTelefone() {
        return telefone;
    }

    public void setTelefone(@NotBlank(message = "Telefone tem que ser obrigatorio.") String telefone) {
        this.telefone = telefone;
    }

    public @NotBlank(message = "CPF é obrigatorio.") String getCpf() {
        return cpf;
    }

    public void setCpf(@NotBlank(message = "CPF é obrigatorio.") String cpf) {
        this.cpf = cpf;
    }

    public @NotBlank(message = "CEP é obrigatorio.") String getCep() {
        return cep;
    }

    public void setCep(@NotBlank(message = "CEP é obrigatorio.") String cep) {
        this.cep = cep;
    }

    public @NotBlank(message = "E-mail e obrigatorio.") @Email(message = "Deve ser um e-mail valido.") String getEmail() {
        return email;
    }

    public void setEmail(@NotBlank(message = "E-mail e obrigatorio.") @Email(message = "Deve ser um e-mail valido.") String email) {
        this.email = email;
    }

    public @NotBlank(message = "Senha e obrigatorio.") @Size(min = 3, message = "A senha deve ter no minimo 3 caracteres.") String getSenha() {
        return senha;
    }

    public void setSenha(@NotBlank(message = "Senha e obrigatorio.") @Size(min = 3, message = "A senha deve ter no minimo 3 caracteres.") String senha) {
        this.senha = senha;
    }

    @Override
    public String toString() {
        return "Usuario{" +
                "id=" + id +
                ", nome='" + nome + '\'' +
                ", telefone='" + telefone + '\'' +
                ", cpf='" + cpf + '\'' +
                ", cep='" + cep + '\'' +
                ", email='" + email + '\'' +
                ", senha='" + senha + '\'' +
                '}';
    }
}
