package com.example.aula.exception;

public class NumeroCamisaJaCadastradoException extends RuntimeException {
    public NumeroCamisaJaCadastradoException(String message) {
        super(message);
    }
}
