import { useState } from 'react';
import logo from './assests/images/logo.png';
import fundo from './assests/images/background.svg';
import UserInput from './components/UserInput';
import UserList from './components/UserList';
import './App.css';

function App() {
  // Permite adicionar estado ao componente (monitorar mudanças no conteúdo).
  const [usuarios, setUsuarios] = useState(['Maria', 'Lucas', 'José']);

  const adicionarUsuarios = (novoUsuario) => {
    // Verificando se o novo usuário já existe na lista.
    if(usuarios.includes(novoUsuario)){
      alert('Usuário já exste na lista');
      return;
    }

    // Adicionar novo usuário nalista, mantendo os anteriores.
    setUsuarios([...usuarios, novoUsuario]);
    // Limpar campo de entrada.
    setUsuarios([...usuarios, novoUsuario]); 
  }

  return (
    <div className = 'App'>
      <img src={logo} alt="logo" />
      <img2 src={fundo} alt="fundo" />
      <h2>Adicionar usuários</h2>
      <h1>Meu App</h1>
        <hr/>
        <UserInput onAddUser={adicionarUsuarios}/>
        <hr/>
        <UserList usuarios={usuarios}/>
    </div>
  );
}

export default App;
