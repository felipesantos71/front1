for (i = 50; i <= 60; i++) {
    if (i %2 == 0) {
        console.log(i);
    }
}