// operadores logicos
let nome1 = 'Maria';
let nome2 = 'Maria';

let idade1 = 10;
let idade2 = '10';

console.log('\nIGUAL');
console.log(nome1 === nome2);
console.log(idade1 == idade2);
console.log(idade1 === idade2);

console.log('\nDIFERENTE');
console.log(nome1 != nome2);
console.log(idade1 !== idade2);

console.log('\nAND');
console.log(1 < 2 && 1 < 3);
console.log(10 < 2 && 1 < 3);

console.log('\nOR');
console.log(10 < 2 || 1 < 3);
