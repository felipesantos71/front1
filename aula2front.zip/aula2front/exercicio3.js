let a = 5;
let b = 5;
let c = 0;

if (a === b) {
    c = a + b;
} else {
    c = a * b;
}

console.log(`Total C: ${c}`);