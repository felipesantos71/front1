let opcao = 3;

switch (opcao) {
    case 1:
        console.log("Opcao 1");
        break;
    case 2:
        console.log("Opcao 2");
        break;
    case 3:
        console.log("Opcao 3");
        break;
    default:
        console.log("Opcao invalida.");
        break;
}