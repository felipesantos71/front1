function somar(a, b) {
    return a + b;
}

const soma = somar(2,3);

console.log(`Soma: ${soma}`);

function subtrair(a, b) {
    return a - b;
}

const subtracao = subtrair(2, 4);

console.log(`Subtracao: ${subtracao}`);