let numero = 3;

if (numero %2 == 0) {
    console.log("E par.");
} else {
    console.log("E impar");
}