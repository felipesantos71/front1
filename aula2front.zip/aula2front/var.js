//variavel
var nome = 'Maria';

console.log(`Nome: ${nome}`);