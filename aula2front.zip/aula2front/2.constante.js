// constantes
const idade = 20;

//tentando mudar o valor de uma constante
// idade = 30;
console.log('idade:', idade);

// template string
console.log(`Idade 2: ${idade}`);