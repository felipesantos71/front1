const idade = 15;

if (idade > 18) {
    console.log("Maior de idade.");
} else if (idade >= 14) {
    console.log("Adolescente.");
} else {
    console.log("Crianca.");
}
