function parImpar(a) {
    if (a > 0) {
        resultado = "positivo";
    } else {
        resultado = "negativo";
    }
    return resultado;
}

let numero = parImpar(-1);

console.log(numero);