let opcao = 7;

switch (opcao) {
    case 1:
        console.log("Domingo");
        console.log("Final de semana");
        break;
    case 2:
        console.log("Segunda");
        console.log("Dia util");
        break;
    case 3:
        console.log("Terca");
        console.log("Dia util");
        break;
    case 4:
        console.log("Quarta");
        console.log("Dia util");
        break;
    case 5:
        console.log("Quinta");
        console.log("Dia util");
        break;
    case 6:
        console.log("Sexta");
        console.log("Dia util");
        break;
    case 7:
        console.log("Sabado");
        console.log("Final de semana");
        break;
    default:
        console.log("Opcao invalida");
        break;
}