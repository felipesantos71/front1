//variaveis
let nome = 'Maria';

nome = 'Joao';
//exibir console
console.log(nome);

console.log(`Nome: ${nome}`)