let a = 2;
let b = 1;
let c = 3;

if (a + b < c) {
    console.log("A + B é menor que C.");
} else if (a + b === c) {
    console.log("A + B é igual a C.");
} else {
    console.log("A + B é maior que C.");
}