let idade = 65;

if (idade > 64) {
    console.log("Não é obrigatorio votar.");
}  else if (idade > 17) {
    console.log("Obrigatorio votar.");
}  else if (idade > 15) {
    console.log("Voto opcional.");
}  else {
    console.log("Não pode votar");
}