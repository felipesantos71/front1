//criando funcao arrow para media
const media = (a, b) => (a + b) / 2;

//calculando media
const mediaNumeros = media(6, 6);

//exibindo
console.log(`Media: ${mediaNumeros}`);