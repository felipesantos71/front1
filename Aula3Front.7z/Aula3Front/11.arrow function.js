//criando a funcao arrow.
const somar = (a, b) => {
    return a + b;
}

const dividir = (a, b) => {
    return a / b;
}

//funcao arrow em uma linha
const subtrair = (a, b) => a - b;
const multiplicar = (a, b) => a * b;

//chamando a funcao.
const soma = somar(2,3);
const subtracao = subtrair(2,3);
const multiplicacao = multiplicar(2,3);
const divisao = dividir(3,3);

//exibir.
console.log(`Soma: ${soma}`);
console.log(`Subtracao: ${subtracao}`);
console.log(`Multiplicacao: ${multiplicacao}`);
console.log(`Divisao: ${divisao}`);