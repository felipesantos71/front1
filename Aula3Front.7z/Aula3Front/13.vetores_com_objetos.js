//criando um vetor de objetos.
const usuarios = [
    {nome: 'Maria', idade: 30},
    {nome: 'Josue', idade: 56},
    {nome: 'Cariane', idade: 35},
    {nome: 'Marilia', idade: 38}
];



//Exibindo.
//console.log(usuarios);
usuarios.forEach(usuario => {
    console.log(`${usuario.nome} \nidade: ${usuario.idade}`)
});
