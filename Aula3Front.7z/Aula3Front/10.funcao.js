//criando funcao.
function somar(a, b) {
    return a + b;
}

function subtrair(a, b) {
    return a - b;
}

function multiplicar(a, b) {
    return a * b;
}

function dividir(a, b) {
    return a / b;
}

//chamando a funcao
const soma = somar(2,3);
const subtracao = subtrair(2,3);
const multiplicacao = multiplicar(2,3);
const divisao = dividir(2,3);

//exibindo 
console.log(`Soma: ${soma}`);
console.log(`Subtracao: ${subtracao}`);
console.log(`Multiplicacao: ${multiplicacao}`);
console.log(`Divisao: ${divisao}`);

    