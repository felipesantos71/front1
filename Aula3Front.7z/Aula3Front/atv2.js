//vetor com 3 numeros e media.
const media = (notas) => {
    const soma = notas.reduce((acc, ntoa) => acc + notas,0);
    return soma / length;
}

notas.array.forEach(element => {
    console.log(`Notas: ${notas}`);
});

console.log(`Media: ${media(notas)}`);
