//vetor com 6 numeros e informe de pares e impares.

const numeros = [1,2,3,4,5,6];

console.log('Filtrando numeros pares.');
const pares = numeros.filter(numero => numero % 2 === 0);
console.log(`Pares: ${pares}\n`);

console.log('Filtrando numeros impares.');
const impares = numeros.filter(numero => numero % 1 === 0);
console.log(`Impares: ${impares}`);