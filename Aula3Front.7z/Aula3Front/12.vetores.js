// Criando um vetor.
const frutas = ['Maca', 'Banana', 'Laranja'];

//Acessar elementos especificos
console.log(frutas[0], frutas[2]);

//Adicionando elementos.
frutas.push('Uvas');
console.log(frutas);

//Remover elemento.
frutas.pop(); // remove o ultimo elemento.
console.log(frutas);

frutas.splice(1,1); // remove apenas o segundo elemento.
console.log(frutas);

//Percorrendo vetor
frutas.forEach((fruta, index) => {
    console.log(`${index}: ${fruta}`);
});